=== Silence Is Not Bad ===
Contributors: Chinawp.info
Author URI: http://Chinawp.info
Tags:admin bar,plugin/theme update notice,upgrade notice
Requires at least: 2.0
Tested up to: 3.3.1

Do not hope your subscriber or co-authoers view admin bar, plugin/theme update notice, upgrade notice... and so on? This plugin can allow/disallow these notice for different user roles.
== Description ==
Plugin Name: Silence Is Not Bad<br>
Plugin Support URI: http://www.chinawp.info/silence-is-not-bad/<br>

My co-author and my users of mu network told me they do not hope view something like plugin/theme update notice, wordpress upgrade notice, because they can not do it, why show these notice to theme every time? Also why show admin bar for Subscriber? Of course they are right,Silence Is Not Bad. I decide remove them,  only core users can view these notices, my new plugin --  "Silence Is Not Bad" will allow us allow/disallow these notice or admin notice bar based on different roles

It is easy, you just select user group, only checked user group will view admin bar on front end, or get notice of wordpress upgrade, or found their plugin & theme have new updates. 

== Installation ==

1:Upload the Silence Is Not Bad plugin to your blog
2:Activate it 
3:select user group

1, 2, 3: You're done!

== Screenshots ==

http://www.chinawp.info/silence-is-not-bad/

== Frequently Asked Questions ==
FAQs can be found here: http://www.chinawp.info/silence-is-not-bad/

== Changelog ==

= Version 1.0.0 =

* Spell out that the license is GPLv2
* Finished the first version
* General code clean up

== Download ==
http://www.chinawp.info/silence-is-not-bad/